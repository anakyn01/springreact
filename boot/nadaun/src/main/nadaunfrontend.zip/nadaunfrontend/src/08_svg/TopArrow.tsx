const TopArrow = () => {
    return(
<>
<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M13.28 10.0332L8.9333 5.68651C8.41997 5.17318 7.57997 5.17318 7.06664 5.68651L2.71997 10.0332" stroke="#B7B7B7" stroke-width="1.7" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

</>
    );
}
export default TopArrow;