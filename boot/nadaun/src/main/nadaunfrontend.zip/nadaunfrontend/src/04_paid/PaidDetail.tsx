import Footer from "../include/Footer";
import DetailHeader from "../include/DetailHeader";
import Tab_Detail from "../include/Tab_Detail";


const PaidDetail = () => {
    return(
<>

   <div className="Min390Max">
    
        <DetailHeader/>
        <Tab_Detail/>

    
    </div>
    <Footer/>
</>
    );  
}
export default PaidDetail;