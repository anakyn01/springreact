import PhoneTop from "../08_svg/PhoneTop";

const HpTop2 = () => {
    return(
<>
<PhoneTop/>
</>
    )
}
export default HpTop2;