function Anatomy(){
    return(
<>
<header className="header">
<div className="logo">
    <img src="/svg/logo.png" alt="" />
</div>
<div className="person">
    <img src="/svg/person.png" alt="" />
</div>
</header>
</>        
    );
}
export default Anatomy;