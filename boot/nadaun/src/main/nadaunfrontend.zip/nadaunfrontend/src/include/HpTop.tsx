import PhoneTop from "../08_svg/PhoneTop";

const HpTop = () => {
    return(
<>
<PhoneTop/>
</>
    )
}
export default HpTop;